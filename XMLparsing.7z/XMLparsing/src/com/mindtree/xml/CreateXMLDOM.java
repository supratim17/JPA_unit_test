package com.mindtree.xml;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

import com.mindtree.entity.Employee;

public class CreateXMLDOM {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
			ArrayList<Employee> empList = EmployeeList.getList();
			Iterator<Employee> itr = empList.iterator();
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder;
			docBuilder = dbFactory.newDocumentBuilder();
			Document doc = docBuilder.newDocument();
			Element mainRootElement = doc.createElementNS("Employee Data", "Employees");
			doc.appendChild(mainRootElement);
			while(itr.hasNext())
			{
				Employee emp = (Employee) itr.next();
				mainRootElement.appendChild(getEmployee(doc, emp.getFirstName(), emp.getLastName(), emp.getDesignation(), String.valueOf(emp.getSalary())));
			}
			Transformer transformer = TransformerFactory.newInstance().newTransformer();
			transformer.setOutputProperty(OutputKeys.INDENT, "yes");
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(System.out);
			/*StreamResult result = new StreamResult("empData.xml");*/
			transformer.transform(source, result);
		}catch(Exception e){
			System.out.println(e.getMessage());
		}
	}
	
	//create children under a specific tag
	private static Node getEmployee(Document doc, String name, String lname, String role, String salary) {
        Element employee = doc.createElement("Employee");
        employee.appendChild(getEmployeeElements(doc, employee, "firstname", name));
        employee.appendChild(getEmployeeElements(doc, employee, "lastname", lname));
        employee.appendChild(getEmployeeElements(doc, employee, "designation", role));
        employee.appendChild(getEmployeeElements(doc, employee, "salary", salary));
        return employee;
    }
	
	//set value for a single tag
	private static Node getEmployeeElements(Document doc, Element element, String name, String value) {
        Element node = doc.createElement(name);
        node.appendChild(doc.createTextNode(value));
        return node;
    }
}
