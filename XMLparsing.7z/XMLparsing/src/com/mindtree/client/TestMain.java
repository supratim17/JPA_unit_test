package com.mindtree.client;

import java.util.ArrayList;

import com.mindtree.entity.Employee;
import com.mindtree.xml.DomParser;

public class TestMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Employee> empList=DomParser.parseData();
		for(Employee emp:empList)
		{
			System.out.println(emp.toString());
		}
	}

}
